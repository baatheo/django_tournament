from django.apps import AppConfig


class TournamentbeConfig(AppConfig):
    name = 'tournamentbe'
